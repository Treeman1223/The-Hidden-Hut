# The Hidden Hut Blog

This is a simple blog website where users can post blog posts, comment on them, and create customizable profiles.

## Features
- Post blogs without the need for an account
- Comment on blog posts and profiles
- Edit profile and customize the appearance

## Technologies Used
- React
- Tailwind CSS (for styling)
- Framer Motion (for animations)

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/the-hidden-hut.git
   ```