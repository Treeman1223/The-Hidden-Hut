import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function BlogSite() {
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [posts, setPosts] = useState([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState("");
  const [profileComments, setProfileComments] = useState([]);
  const [profileCommentText, setProfileCommentText] = useState("");
  const [editingProfile, setEditingProfile] = useState(false);
  const [editingPostId, setEditingPostId] = useState(null);
  const [viewProfile, setViewProfile] = useState(false);

  const [profile, setProfile] = useState({
    name: "Anonymous",
    bio: "",
    backgroundColor: "#ffffff",
    textColor: "#000000",
    avatarUrl: "",
    musicUrl: "",
    profilePicture: ""
  });

  const handlePost = () => {
    if (title && content) {
      setPosts([{ title, content, date: new Date().toLocaleString(), id: Date.now() }, ...posts]);
      setTitle("");
      setContent("");
    }
  };

  const deletePost = (postId) => {
    setPosts(posts.filter(post => post.id !== postId));
    setComments(comments.filter(comment => comment.postId !== postId));
  };

  const addComment = (postId) => {
    if (commentText) {
      setComments([...comments, { postId, text: commentText }]);
      setCommentText("");
    }
  };

  const addProfileComment = () => {
    if (profileCommentText) {
      setProfileComments([...profileComments, profileCommentText]);
      setProfileCommentText("");
    }
  };

  const updateProfile = (e) => {
    e.preventDefault();
    setEditingProfile(false);
  };

  const updatePost = (postId, updatedTitle, updatedContent) => {
    setPosts(
      posts.map(post =>
        post.id === postId ? { ...post, title: updatedTitle, content: updatedContent } : post
      )
    );
    setEditingPostId(null);
  };

  if (!ageConfirmed) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <Card className="max-w-md text-center p-6">
          <CardContent>
            <h1 className="text-3xl font-bold mb-4">Welcome to The Hidden Hut</h1>
            <h2 className="text-2xl font-bold mb-4">18+ Only</h2>
            <p className="mb-4">You must be 18 years or older to enter this site.</p>
            <Button onClick={() => setAgeConfirmed(true)}>I am 18 or older</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (viewProfile) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen bg-gray-100 p-6"
      >
        <Button onClick={() => setViewProfile(false)} className="mb-4">Back to Home</Button>
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-4">Your Profile</h2>
          <div style={{ backgroundColor: profile.backgroundColor, color: profile.textColor }} className="p-4 rounded-xl">
            {profile.profilePicture && (
              <img src={profile.profilePicture} alt="Profile" className="w-24 h-24 rounded-full mb-2" />
            )}
            {profile.avatarUrl && (
              <img src={profile.avatarUrl} alt="Avatar" className="w-12 h-12 rounded mb-2" />
            )}
            <h3 className="text-lg font-semibold">{profile.name}</h3>
            <p>{profile.bio}</p>
            {profile.musicUrl && (
              <audio controls className="mt-2 w-full">
                <source src={profile.musicUrl} type="audio/mpeg" />
                Your browser does not support the audio element.
              </audio>
            )}
            <p className="text-sm mt-2 text-blue-500">Public Profile: /profile/{profile.name.toLowerCase().replace(/\s+/g, '-') || 'anonymous'}</p>
            <div className="mt-4">
              <h4 className="font-semibold">Comments on Profile:</h4>
              <Textarea
                placeholder="Leave a comment..."
                value={profileCommentText}
                onChange={(e) => setProfileCommentText(e.target.value)}
                className="mb-2"
              />
              <Button onClick={addProfileComment}>Comment</Button>
              <ul className="mt-2 list-disc list-inside">
                {profileComments.map((c, i) => (
                  <li key={i}>{c}</li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-gray-100 p-6"
    >
      <h1 className="text-4xl font-bold text-center mb-6">The Hidden Hut</h1>
      <div className="max-w-2xl mx-auto">
        <Card className="mb-6 p-6">
          <h2 className="text-xl font-bold mb-4">Post a Blog</h2>
          <Input
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mb-2"
          />
          <Textarea
            placeholder="Write your blog content here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="mb-2"
          />
          <Button onClick={handlePost}>Post</Button>
        </Card>

        <Card className="mb-6 p-6">
          <h2 className="text-xl font-bold mb-4">Your Profile</h2>
          <Button onClick={() => setViewProfile(true)}>View Profile</Button>
          <Button onClick={() => setEditingProfile(true)} className="ml-2">Edit Profile</Button>
          {editingProfile && (
            <form onSubmit={updateProfile} className="mt-4">
              <Input
                placeholder="Name"
                value={profile.name}
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                className="mb-2"
              />
              <Textarea
                placeholder="Bio"
                value={profile.bio}
                onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                className="mb-2"
              />
              <Input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      setProfile({ ...profile, profilePicture: reader.result });
                    };
                    reader.readAsDataURL(file);
                  }
                }}
                className="mb-2"
              />
              <Input
                placeholder="Avatar Icon URL"
                value={profile.avatarUrl}
                onChange={(e) => setProfile({ ...profile, avatarUrl: e.target.value })}
                className="mb-2"
              />
              <Input
                placeholder="Music File URL (MP3)"
                value={profile.musicUrl}
                onChange={(e) => setProfile({ ...profile, musicUrl: e.target.value })}
                className="mb-2"
              />
              <Input
                type="color"
                value={profile.backgroundColor}
                onChange={(e) => setProfile({ ...profile, backgroundColor: e.target.value })}
                className="mb-2"
              />
              <Input
                type="color"
                value={profile.textColor}
                onChange={(e) => setProfile({ ...profile, textColor: e.target.value })}
                className="mb-2"
              />
              <Button type="submit">Save Profile</Button>
            </form>
          )}
        </Card>

        <div>
          {posts.map((post) => (
            <Card key={post.id} className="mb-4 p-4">
              {editingPostId === post.id ? (
                <div>
                  <Input
                    value={post.title}
                    onChange={(e) => {
                      const updatedTitle = e.target.value;
                      setPosts(posts.map(p => p.id === post.id ? { ...p, title: updatedTitle } : p));
                    }}
                    className="mb-2"
                  />
                  <Textarea
                    value={post.content}
                    onChange={(e) => {
                      const updatedContent = e.target.value;
                      setPosts(posts.map(p => p.id === post.id ? { ...p, content: updatedContent } : p));
                    }}
                    className="mb-2"
                  />
                  <Button onClick={() => updatePost(post.id, post.title, post.content)}>Save</Button>
                </div>
              ) : (
                <>
                  <h3 className="text-lg font-semibold">{post.title}</h3>
                  <p className="text-sm text-gray-500">Posted on {post.date}</p>
                  <p className="mt-2 whitespace-pre-wrap">{post.content}</p>
                  <Button onClick={() => setEditingPostId(post.id)} className="mt-2 mr-2">Edit Post</Button>
                  <Button onClick={() => deletePost(post.id)} variant="destructive" className="mt-2">Delete Post</Button>
                </>
              )}
              <div className="mt-4">
                <h4 className="font-semibold">Comments:</h4>
                <Textarea
                  placeholder="Add a comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="mb-2"
                />
                <Button onClick={() => addComment(post.id)}>Comment</Button>
                <ul className="mt-2 list-disc list-inside">
                  {comments.filter((c) => c.postId === post.id).map((c, i) => (
                    <li key={i}>{c.text}</li>
                  ))}
                </ul>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </motion.div>
  );
}